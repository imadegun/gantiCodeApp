import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ClientCode Management System",
  description: "Efficiently manage and update ClientCode for collection items with search, filters, and pagination.",
  keywords: ["ClientCode", "Management", "Collection", "MySQL", "Next.js", "TypeScript"],
  authors: [{ name: "ClientCode Management Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "ClientCode Management System",
    description: "Efficiently manage and update ClientCode for collection items",
    url: "https://chat.z.ai",
    siteName: "ClientCode Management",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ClientCode Management System",
    description: "Efficiently manage and update ClientCode for collection items",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
