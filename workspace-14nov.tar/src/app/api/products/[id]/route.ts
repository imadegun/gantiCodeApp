import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/mysql';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url).searchParams;
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Product ID is required' },
        { status: 400 }
      );
    }

    // Get main product details
    const productSql = `
      SELECT 
        tm.*,
        td.DesignName,
        tc.CategoryName,
        ts.SizeName,
        tmn.TextureName,
        tmn.MaterialName,
        tmn.ColorName,
        tcl.TextureName,
        tcl.MaterialName,
        tcl.ColorName,
        tbgl.GlazeDescription,
        tbst.StainOxideDescription,
        tble.LustreDescription,
        tbeng.EngobeDescription,
        tbt.ToolsDescription,
        tbs.SizeName,
        tbu.UnitValue
      FROM tblcollect_master tm
      LEFT JOIN tblcollect_design td ON tm.DesignCode = td.DesignCode
      LEFT JOIN tblcollect_category tc ON tm.CategoryCode = tc.CategoryCode
      LEFT JOIN tblcollect_size ts ON tm.SizeCode = ts.SizeCode
      LEFT JOIN tblcollect_texture tmn ON tm.TextureCode = tmn.TextureCode
      LEFT JOIN tblcollect_material tmn ON tm.MaterialCode = tmn.MaterialCode
      LEFT JOIN tblcollect_color tmn ON tm.ColorCode = tmn.ColorCode
      LEFT JOIN tblglaze tbgl ON tm.GlazeCode = tbgl.GlazeCode
      LEFT JOIN tblstainoxide tbst ON tm.StainOxideCode = tbst.StainOxideCode
      LEFT JOIN tblustre tble ON tm.LustreCode = tble.LustreCode
      LEFT JOIN tblengobe tbeng ON tm.EngobeCode = tbeng.EngobeCode
      LEFT JOIN tbltools tbt ON tm.ToolsCode = tbt.ToolsCode
      LEFT JOIN tblsize tbs ON tm.SizeCode = tbs.SizeCode
      LEFT JOIN tblunit tbu ON tm.UnitCode = tbu.UnitValue
      WHERE tm.ID = ?
    `;

    const productResult = await query(productSql, [id]) as any[];

    if (productResult.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Product not found' },
        { status: 404 }
      );
    }

    const product = productResult[0];

    // Get related items (same design, category, size)
    const relatedSql = `
      SELECT 
        ID, ClientCode, Photo1, Photo2, Photo3, Photo4,
        DesignName, CategoryName, SizeName
      FROM tblcollect_master 
      WHERE DesignCode = ? AND CategoryCode = ? AND SizeCode = ?
      ORDER BY ID DESC
      LIMIT 10
    `;

    const relatedResult = await query(relatedSql, [product.DesignCode, product.CategoryCode, product.SizeCode]) as any[];

    return NextResponse.json({
      success: true,
      data: {
        product,
        relatedItems: relatedResult
      }
    });
  } catch (error) {
    console.error('Error fetching product details:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch product details' },
      { status: 500 }
    );
  }
}