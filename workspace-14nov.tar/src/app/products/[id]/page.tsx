'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Image as ImageIcon, Package, Ruler, Palette, Droplets, Settings, Eye, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

interface Product {
  ID: number;
  ClientCode: string | null;
  DesignCode: string;
  CategoryCode: string;
  SizeCode: string;
  Photo1: string | null;
  Photo2: string | null;
  Photo3: string | null;
  Photo4: string | null;
  DesignName: string;
  CategoryName: string;
  SizeName: string;
  TextureName: string;
  MaterialName: string;
  ColorName: string;
  GlazeDescription: string;
  StainOxideDescription: string;
  LustreDescription: string;
  EngobeDescription: string;
  ToolsDescription: string;
  UnitValue: string;
  NameDesc: string;
}

interface RelatedItem {
  ID: number;
  ClientCode: string | null;
  Photo1: string | null;
  Photo2: string | null;
  Photo3: string | null;
  Photo4: string | null;
  DesignName: string;
  CategoryName: string;
  SizeName: string;
}

export default function ProductDetailPage() {
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedItems, setRelatedItems] = useState<RelatedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('basic');
  const params = useParams();
  const router = useRouter();

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        const response = await fetch('/api/products/' + params.id);
        const result = await response.json();
        
        if (result.success) {
          setProduct(result.data.product);
          setRelatedItems(result.data.relatedItems);
        } else {
          toast.error('Failed to load product details');
        }
      } catch (error) {
        console.error('Error fetching product:', error);
        toast.error('Failed to load product details');
      } finally {
        setLoading(false);
      }
    };

    if (params.id) {
      fetchProductData();
    }
  }, [params.id]);

  const handleBack = () => {
    router.push('/');
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto p-4 max-w-7xl">
          {/* Loading State */}
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-4 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading product details...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto p-4 max-w-7xl">
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-foreground mb-4">Product Not Found</h1>
              <p className="text-muted-foreground mb-6">The product you're looking for doesn't exist or has been removed.</p>
              <Button onClick={handleBack} variant="outline" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Product List
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const formatValue = (value: string | null, unit?: string) => {
    if (!value) return '-';
    return unit ? `${value} ${unit}` : value;
  };

  const formatDescription = (value: string | null) => {
    if (!value) return 'No description available';
    return value;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-4 max-w-7xl">
        {/* Header */}
        <div className="mb-6">
          <Button onClick={handleBack} variant="outline" className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Product List
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-2">Product Details</h1>
            <p className="text-muted-foreground">View comprehensive product information and technical specifications</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Product Images */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  Product Images
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[product.Photo1, product.Photo2, product.Photo3, product.Photo4].map((photo, index) => (
                    <div key={index} className="relative group">
                      {photo ? (
                        <div className="aspect-square overflow-hidden rounded-lg border bg-muted">
                          <img 
                            src={photo.startsWith('http') ? photo : `http://192.168.1.110/upload/' + photo}
                            alt={item.DesignName}
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              e.currentTarget.nextElementSibling?.classList.remove('hidden');
                            }}
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-0 transition-opacity duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                            <Eye className="w-6 h-6 text-white" />
                          </div>
                        </div>
                      ) : (
                        <div className="aspect-square overflow-hidden rounded-lg border bg-muted flex items-center justify-center">
                          <ImageIcon className="w-12 h-12 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                  </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Product Information */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Product Code</h3>
                    <p className="text-lg font-semibold">{product.CollectCode || '-'}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Client Code</h3>
                    <p className="text-lg font-semibold">{product.ClientCode || 'Not assigned'}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Design Name</h3>
                    <p className="text-lg font-semibold">{product.DesignName}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Category</h3>
                    <p className="text-lg font-semibold">{product.CategoryName}</h3>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Size</h3>
                    <p className="text-lg font-semibold">{product.SizeName}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Technical Specifications */}
            <Card>
              <CardHeader>
                <CardTitle>Technical Specifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Dimensions</h3>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Ruler className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <span className="font-medium">Width:</span>
                          <span className="ml-2">{formatValue(product.Width?.toString(), product.UnitValue)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Ruler className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <span className="font-medium">Height:</span>
                          <span className="ml-2">{formatValue(product.Height?.toString(), product.UnitValue)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Ruler className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <span className="font-medium">Length:</span>
                          <span className="ml-2">{formatValue(product.Length?.toString(), product.UnitValue)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Ruler className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <span className="font-medium">Diameter:</span>
                          <span className="ml-2">{formatValue(product.Diameter?.toString(), product.UnitValue)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                      <div className="flex items-center gap-2">
                        <Ruler className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <span className="font-medium">Volume:</span>
                          <span className="ml-2">{formatValue(product.SampCeramicVolume?.toString(), 'cm³')}</span>
                        </div>
                      </div>
                      </div>
                  </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Materials & Finishes */}
            <Card>
              <CardHeader>
                <CardTitle>Materials & Finishes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Material</h3>
                    <p className="text-lg font-semibold">{product.MaterialName || '-'}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Texture</h3>
                    <p className="text-lg font-semibold">{product.TextureName || '-'}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Color</h3>
                    <p className="text-lg font-semibold">{product.ColorName || '-'}</p>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded border" style={{ backgroundColor: product.ColorName || '#ccc' }}></div>
                      <span className="ml-2">{product.ColorName || '-'}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Production Process */}
            <Card>
              <CardHeader>
                <CardTitle>Production Process</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Glaze</h3>
                    <p className="text-lg font-semibold">{formatDescription(product.GlazeDescription)}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Bisque Temperature</h3>
                    <p className="text-lg font-semibold">{product.GlazeTechnique || '-'}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Glaze Technique</h3>
                    <p className="text-lg font-semibold">{product.LastUpdate || '-'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

            {/* Additional Information */}
            <Card>
              <CardHeader>
                <CardTitle>Additional Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Description</h3>
                    <p className="text-lg font-semibold">{formatDescription(product.NameDesc)}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Unit</h3>
                    <p className="text-lg font-semibold">{product.UnitValue || '-'}</p>
                  </div>
                </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Last Update</h3>
                    <p className="text-lg font-semibold">{product.LastUpdate || '-'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }
}